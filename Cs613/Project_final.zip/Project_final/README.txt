

	Please follow the steps below:

	1) Run Joint_Data_Extraction.ipynb
		
		1.1) This creates an excel file (Joint_Data.xlsx). For the purposes of completion, the file is already attached in the zip file.

	2) Run CaseStudy.ipynb
